#include <stdio.h>

#define SIZE 256

int main(int argc, char *argv[]) {
    if (argc != 4){
        printf("ERROR : ARGS ==> [file_exc] [login] [id] [key]\n");
        return 0;
    }

    char*   login       = argv[1];
    int     fd_write    = atoi(argv[2]);
    int     clef        = atoi(argv[3]);

    char buffer_read[SIZE];
    char buffer_send[SIZE];
    
    printf("Hello %s \n",login);
    printf("Tapez 'exit' pour quitter. \n");


    while (1) {

        printf("Tapez votre message: ");
        scanf("%s", buffer_read);

        if (!strcmp(buffer_read, "exit"))
            break;

        sprintf(buffer_send, "%s: %s", login, buffer_read);

        write(fd_write, buffer_send, SIZE);

    }

    printf("Good bye %s \n", login);

    return 0;
}