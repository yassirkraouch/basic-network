#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <semaphore.h>

#define SIZE 256
#define PORT 5000
#define NB_CLIENTS_MAX 10

struct info_client {
    char login[10];
    int socket;
};

struct info_client annuaire[NB_CLIENTS_MAX];

pthread_mutex_t mutex;
sem_t semaphore;
int listen_sock;

void init() {
    for (int i = 0; i < NB_CLIENTS_MAX; ++i) {
        annuaire[i].login[0] = '\0';
        annuaire[i].socket = -1;
    }

    pthread_mutex_init(&mutex, NULL);

    sem_init(&semaphore, 0, 25);

    struct sockaddr_in sv_adr;
    sv_adr.sin_family = AF_INET;
    sv_adr.sin_port = htons(PORT);
    sv_adr.sin_addr.s_addr = INADDR_ANY;
    listen_sock = socket(AF_INET, SOCK_STREAM, 0);
    bind(listen_sock, (struct sockaddr *)&sv_adr, sizeof(sv_adr));
    listen(listen_sock, NB_CLIENTS_MAX);
}

int login_exists(char *login) {
    for (int i = 0; i < NB_CLIENTS_MAX; ++i)
        if (!strcmp(login, annuaire[i].login))
            return 1;
    return 0;
}

void broadcast_message(int index, char *message) {
    pthread_mutex_lock(&mutex);
    for (int i = 0; i < NB_CLIENTS_MAX; ++i) {
        if (annuaire[i].socket != -1 && i != index) {
            send(annuaire[i].socket, message, strlen(message), 0);
        }
    }
    pthread_mutex_unlock(&mutex);
}

int authenticate_client(int s) {
    char login[10];
    recv(s, login, 10, 0);

    if (!login_exists(login)) {
        for (int i = 0; i < NB_CLIENTS_MAX; ++i) {
            if (annuaire[i].socket == -1) {
                strcpy(annuaire[i].login, login);
                annuaire[i].socket = s;
                char resp = 1;
                send(s, &resp, 1, 0);
                printf("client %s authenticated\n", login);
                return i;
            }
        }
        printf("server is full\n");
    } else {
        printf("login %s already exists\n", login);
    }

    char resp = 0;
    send(s, &resp, 1, 0);

    return -1;
}

void *communication_with_client(void *arg) {
    int sock = *(int *)arg;
    char message[SIZE];

    int index = authenticate_client(sock);
    if (index != -1) {
        while (1) {
            if (recv(sock, message, SIZE, 0) <= 0) {
                printf("client \"%s\" has left\n", annuaire[index].login);
                pthread_mutex_lock(&mutex);
                annuaire[index].login[0] = '\0';
                annuaire[index].socket = -1;
                pthread_mutex_unlock(&mutex);
                break;
            }
            
            printf("%s\n", message);
            broadcast_message(index, message);
        }
    }

    sem_post(&semaphore);
}

int main() {
    init();

    while (1) {
        int sock = accept(listen_sock, NULL, NULL);
        sem_wait(&semaphore);
        pthread_t thread;
        pthread_create(&thread, NULL, communication_with_client, &sock);
    }

    return 0;
}
